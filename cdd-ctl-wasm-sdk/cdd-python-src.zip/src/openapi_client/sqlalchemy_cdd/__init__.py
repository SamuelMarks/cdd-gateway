"""SQLAlchemy code generation module."""
