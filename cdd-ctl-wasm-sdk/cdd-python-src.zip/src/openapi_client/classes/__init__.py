"""Module containing initialization logic."""
