"""FastAPI code generation module."""
